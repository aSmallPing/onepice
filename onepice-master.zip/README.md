Ghost主题
===

onepice是一款适用于ghost的博客主题。

反馈
===

在你浏览或使用本主题时，发现问题或者是有好的建议，希望能够在这里给予反馈。

[New Issue](https://github.com/guovz/onepice/issues/new)

License
===
MIT License
